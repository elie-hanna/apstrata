({
	loadingState: "正在装入...",
	errorState: "对不起，发生了错误"
})
