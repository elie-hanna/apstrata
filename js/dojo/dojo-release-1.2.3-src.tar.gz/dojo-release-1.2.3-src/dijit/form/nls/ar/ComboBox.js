({
		previousMessage: "الاختيارات السابقة ",
		nextMessage: "مزيد من الاختيارات "
})
