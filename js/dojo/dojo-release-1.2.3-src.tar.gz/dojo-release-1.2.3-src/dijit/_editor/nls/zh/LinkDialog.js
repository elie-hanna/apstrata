({
	createLinkTitle: "链接属性",
	insertImageTitle: "图像属性",
	url: "URL：",
	text: "描述：",
	set: "确定"
})
