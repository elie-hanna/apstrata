({
	createLinkTitle: "Proprietà collegamento",
	insertImageTitle: "Proprietà immagine",
	url: "URL:",
	text: "Descrizione:",
	set: "Imposta"
})
