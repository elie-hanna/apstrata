({
	createLinkTitle: "Propriétés du lien",
	insertImageTitle: "Propriétés de l'image",
	url: "URL :",
	text: "Description :",
	set: "Définir"
})
