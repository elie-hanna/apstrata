({
	createLinkTitle: "Vlastnosti odkazu",
	insertImageTitle: "Vlastnosti obrázku",
	url: "Adresa URL:",
	text: "Popis:",
	set: "Nastavit"
})
