({
	fontSize: "Tamanho",
	fontName: "Fonte",
	formatBlock: "Formato",

	serif: "serif",
	"sans-serif": "sans-serif",
	monospace: "monoespaçado",
	cursive: "cursive",
	fantasy: "fantasy",

	p: "Parágrafo",
	h1: "Título",
	h2: "Subcabeçalho",
	h3: "Sub-subcabeçalho",
	pre: "Pré-formatado",

	1: "xx-small",
	2: "x-small",
	3: "small",
	4: "medium",
	5: "large",
	6: "x-large",
	7: "xx-large "
})
