({
	createLinkTitle: "リンク・プロパティー",
	insertImageTitle: "イメージ・プロパティー",
	url: "URL:",
	text: "説明:",
	set: "設定"
})
